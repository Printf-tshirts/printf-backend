const Product = require("../models/products.model");
const Variant = require("../models/variants.model");
const Category = require("../models/categories.model");

const addProduct = async (req, res) => {
  try {
    const product = await Product.create(req.body);
    res.status(200).json({ product });
  } catch (error) {
    res.status(500).json({ error });
  }
};

const getProducts = async (req, res) => {
  try {
    const products = await Product.find()
      .populate("categories")
      .skip(req.query.skip)
      .limit(req.query.limit);
    res.status(200).json({ products });
  } catch (error) {
    res.status(500).json({ error });
  }
};

const getProduct = async (req, res) => {
  try {
    console.log(req.query.productId);
    const product = await Product.findById(req.query.productId).populate({
      path: "variants",
      populate: {
        path: "images",
      },
    });
    res.status(200).json({ product });
  } catch (error) {
    res.status(500).json({ error });
  }
};

const getProductByVariantHandle = async (req, res) => {
  try {
    const category = await Category.findOne({
      handle: req.query.categoryHandle,
    });
    if (!category) return res.status(404).json({ error: "Category not found" });
    const variant = await Variant.findOne({
      handle: req.query.variantHandle,
      product_code: req.query.productCode,
      categories: { $in: category._id },
    });
    if (!variant) return res.status(404).json({ error: "Variant not found" });
    const product = await Product.findOne({
      variants: { $in: variant._id },
    })
      .populate({
        path: "variants",
        populate: [
          {
            path: "images",
          },
          {
            path: "categories",
          },
        ],
      })
      .populate("categories");
    console.log(product);
    res.status(200).json({ product });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error });
  }
};

const getProductsByCategory = async (req, res) => {
  try {
    let categoryId = req.query.categoryId;
    if (req.query.categoryId === "undefined") {
      const category = await Category.findOne({
        handle: req.query.categoryHandle,
      });
      categoryId = category._id;
    }
    const products = await Product.find({
      categories: { $in: categoryId },
    })
      .populate({
        path: "variants",
        populate: {
          path: "images",
        },
      })
      .populate("categories");
    res.status(200).json({ products });
  } catch (error) {
    res.status(500).json({ error });
  }
};
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.body.productId,
      req.body,
    );
    res.status(200).json({ product });
  } catch (error) {
    res.status(500).json({ error });
  }
};

const updateProductStatus = async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.query.productId,
      {
        isActive: req.body.status,
      },
      {
        new: true,
      },
    );
    res.status(200).json({ product });
  } catch (error) {
    res.status(500).json({ error });
  }
};

module.exports = {
  addProduct,
  getProducts,
  getProduct,
  getProductByVariantHandle,
  updateProduct,
  updateProductStatus,
  getProductsByCategory,
};
