const mongoose = require("mongoose");

const CartSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "users" },
    items: [
      {
        variant: { type: mongoose.Schema.Types.ObjectId, ref: "variants" },
        quantity: { type: Number },
        size: { type: String },
        cartItemId: { type: String },
      },
    ],
    shipping: { type: mongoose.Schema.Types.ObjectId, ref: "shippings" },
    totalPrice: { type: Number },
    totalPriceWithShipping: { type: Number },
    isConvertedToOrder: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  { strict: true, timestamps: true },
);

const Cart = mongoose.model("carts", CartSchema);

module.exports = Cart;
